<?php
/*
Plugin Name: JCMS BPT Connector
Plugin URI: http://www.jcms-consulting.co.uk/jcms-wordpress-plugins.html
Description: Plug-in to expose event tickets list and detail.
Version: 1.0.0
Author: JCMS Consulting
Author URI: http://www.jcms-consulting.co.uk
 */
include "includes/JCMSBPTConnectorInitialise.php";

//see wordpress.stackexchange.com/questions/61437
$plugin = new JCMSBPTConnectorInitialise(); 
