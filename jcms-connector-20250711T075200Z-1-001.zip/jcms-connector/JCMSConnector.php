<?php
/*
Plugin Name: JCMS Connector
Description: A generic http content embedder.
Author JCMS Consulting 
Version: 0.1
tt
 */
include "includes/JCMSConnectorActions.php";
include "includes/JCMSConnectorAdminSetup.php";    //functions to set up the settings page
/*
 * Get content by a content ID. Will use a configured base path and will require appropriate source
 * CMS handlers to retrieve and parse content by the ID.
 * */
function jcms_connector_get_content_by_id($atts){    //shortcode params
    $_out = '';

    if(array_key_exists('id',$atts) && array_key_exists('service',$atts)){
        $_connector = new JCMSConnectorActions();
        $_out = $_connector->getContentById($atts);
        $_connector = null;
//         echo($_out);   //CMS content
    }
    return $_out;
};

/*
 * Get content by a relative path. Will use a configured base path and will require appropriate source
 * CMS modifications to render isolated content, rather than a full HTML page.
 * */
function jcms_connector_get_content_by_path($atts){    //shortcode params
    $_out = null;
    return $_out;
};

/*
 * Add shortcode handlers:
 * There is one for a combination of ID, script and connection name, and one
 * with a combination of name and content path only
 */
add_shortcode('jcms_connector_content_id', 'jcms_connector_get_content_by_id');
add_shortcode('jcms_connector_content_path', 'jcms_connector_get_content_by_path');

/*
 * Enqueue useful scripts
 * */
//register and include scripts:
//see https://code.tutsplus.com/tutorials/loading-css-into-wordpress-the-right-way--cms-20402
function JCMSConnectorEnqueueScripts(){
    wp_register_script(
        'engine',
        plugins_url( '/js/engine.js',__FILE__),  //see developer.wordpress.org/reference/functions/plugin_url/
        array('jquery'),
        1.1,
        true);
    wp_enqueue_script('engine');
    wp_enqueue_script('jquery');
}

function JCMSConnectorEnqueueStyles(){
    wp_register_style('jcms_connector_styles', plugins_url( '/css/jcms_connector_styles.css',__FILE__));
    
    //local jquery UI as CDN usage is discouraged NOTE THAT THE JQueryUI style is not registered by default...
    wp_register_style('jquery-ui', plugins_url( '/css/jquery-ui.css',__FILE__));
    wp_enqueue_style('jcms_connector_styles');
    wp_enqueue_style('jquery-ui');
}

add_action( 'wp_enqueue_scripts', 'JCMSConnectorEnqueueScripts' );
add_action( 'wp_enqueue_scripts', 'JCMSConnectorEnqueueStyles' );

