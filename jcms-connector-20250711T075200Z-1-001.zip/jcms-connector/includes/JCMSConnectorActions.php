<?php
/*
 * Render and manage admin page
 */
class JCMSConnectorActions{
    const JCMS_CONNECTOR_OPTS = 'jcms_connector_opts';
    
    var $_current_jcms_settings = null;
    
    function __construct(){
        $this->_current_jcms_settings = get_option(JCMSConnectorActions::JCMS_CONNECTOR_OPTS);
    }
    
    
    public function getContentById($_attrs){
        $_current_config = $this->getAttributesByConnectionName($_attrs['service']);
//         var_dump($_current_config);
        
        //we need to build teh URL here:
        $_url = $this->buildRequestUrl($_current_config, 'id', $_attrs['id']);
        
        //implement a cache as per here:
        //https://stackoverflow.com/questions/18097432
        $_out = $this->_urlCacheHandler($_url,$_current_config);
        return($_out);
    }
    
    public function getContentByPath($_attrs){
        
    }

    /*
     * Called by shortcode handler expecting to use an ID, a remote handler script and the name
     * */
    public function getAttributesByConnectionName($_service){
        $_out = null;
        foreach ($this->_current_jcms_settings as $_thing ){
            if($_thing[1] == $_service){
                $_out = $_thing;
                break;
            }
        }
        return ($_out);
    }
    
    
    
    public function buildRequestUrl($params,$type,$shortcode_flag){
        $url = null;
        if($type == 'id'){
            $url = $params[2] . '/' . $params[3] . '?' . $params[4] . '=' .  $shortcode_flag;
        }
        elseif ($type == 'path'){
            
        }
        return($url);
    }
    
    
    /*
     * Simple HTTP caching mechanism, based on
     * https://stackoverflow.com/questions/18097432/does-file-get-contents-use-a-cache
     */
    private function _urlCacheHandler($_url,$_conf){
//         echo($_conf[6] . '<br />');
        $_cachetime = 60;   //seconds, default
        if(settype($_conf[6],'integer')){//if settype passes, $_cachetime will be reset
            $_cachetime = $_conf[6];
        };
        
//         echo($_cachetime . '<br />');
        
        $_key = urlencode($_url);
        $_out = null;
        $_cachefile = plugin_dir_path(__FILE__) . $_key . ".cache";
        if(file_exists($_cachefile)){
            if(time() - filemtime($_cachefile) > $_cachetime){
                //refresh cache:
                $_out = @file_get_contents($_url) . '[r]';//The @ symbol suppresses error output
                /*
                 * NOTE: I need to do this check BEFORE I write the cache file, otherwise I will cache responses
                 * that are not HTTP 200 OK.
                 *
                 * Use the following to test:
                 *
                 * var_dump($http_response_header);//$http_response_header might be null. Add error trapping/HTTP response code checking
                 *
                 * Also, create /cache/ directory for these...
                 * */ 
//                 echo($_out);
                if($_out){
//                     var_dump($http_response_header);
                    
                    file_put_contents($_cachefile, $_out);
                }
                else{
                    $_out = '[e]';
//                     echo('Cannot load remote resource ' . $_url);
                }
               

                
            }
            else{
                //get cached contents:
                $_out = file_get_contents($_cachefile) . '[c]';
            }
        }
        else{
            //no cache file, create one:
            $_out = file_get_contents($_url) . '[n]';
            file_put_contents($_cachefile, $_out);
        }
        return($_out);
    }
}

