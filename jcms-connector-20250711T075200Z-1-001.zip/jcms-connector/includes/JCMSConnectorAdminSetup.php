<?php
/*
 * Set up the admin page for the plugin.
 * Not sure whetehr I can convert to a class...
 * 
 * OK Lets make this simpler - I'll specify THREE only sets of fields to populate.
 * TODO: Sort out doing it dynamically later...
 * 
 * Implement as this:
 * www.smashingmagazine.com/2016/04/three-approaches-to-adding-configurable-fields-to-your-plugin
 * */
//see wordpress.stackexchange.com/questions/91764/
add_action('admin_menu','jcms_connector_setup_menu');

function jcms_connector_setup_menu(){      //CALLBACK
    add_options_page('JCMS Connector setup','JCMS Connector','manage_options','jcms-connector','jcms_connector_init');
}

function jcms_connector_init(){     //CALLBACK
    ?>
    <div class="wrap">
    <h2>Configure JCMS Connectors</h2>
    <form action="/wp-admin/options.php" method="post">
    <?php settings_fields('jcms_connector_opts'); ?>
    <?php do_settings_sections('jcms-connector'); ?>
    <table class="form-table"> 
      <tr valign="top">
        <td colspan="2">
            <input name="Submit" type="submit" class="button button-primary" value="<?php esc_attr_e('Save Changes'); ?>" />
        </td>
      </tr>
    </table>
    </form>
    </div>
    <?php
}


add_action('admin_init','jcms_connector_admin_init');
function jcms_connector_admin_init(){     //CALLBACK
    //register_setting('jcms_connector_opts','jcms_connector_opts', 'plugin_options_validate'); 
    register_setting('jcms_connector_opts','jcms_connector_opts'); //no validate function yet
    add_settings_section('jcms_connector_s1', 'Connector 1', null, 'jcms-connector');
    add_settings_field('plugin_text_input1_1', 'Connection name', 'plugin_input1_1', 'jcms-connector', 'jcms_connector_s1');
    add_settings_field('plugin_text_input1_2', 'Server root', 'plugin_input1_2', 'jcms-connector', 'jcms_connector_s1');
    add_settings_field('plugin_text_input1_3', 'Script name', 'plugin_input1_3', 'jcms-connector', 'jcms_connector_s1');
    add_settings_field('plugin_text_input1_4', 'URL paramter name', 'plugin_input1_4', 'jcms-connector', 'jcms_connector_s1');
    add_settings_field('plugin_text_input1_5', 'Content path', 'plugin_input1_5', 'jcms-connector', 'jcms_connector_s1');
    add_settings_field('plugin_text_input1_6', 'Cache time', 'plugin_input1_6', 'jcms-connector', 'jcms_connector_s1');

    add_settings_section('jcms_connector_s2', 'Connector 2', null, 'jcms-connector');
    add_settings_field('plugin_text_input2_1', 'Connection name', 'plugin_input2_1', 'jcms-connector', 'jcms_connector_s2');
    add_settings_field('plugin_text_input2_2', 'Server root', 'plugin_input2_2', 'jcms-connector', 'jcms_connector_s2');
    add_settings_field('plugin_text_input2_3', 'Script name', 'plugin_input2_3', 'jcms-connector', 'jcms_connector_s2');
    add_settings_field('plugin_text_input2_4', 'URL paramter name', 'plugin_input2_4', 'jcms-connector', 'jcms_connector_s2');
    add_settings_field('plugin_text_input2_5', 'Content path', 'plugin_input2_5', 'jcms-connector', 'jcms_connector_s2');
    add_settings_field('plugin_text_input2_6', 'Cache time', 'plugin_input2_6', 'jcms-connector', 'jcms_connector_s2');
    
    add_settings_section('jcms_connector_s3', 'Connector 3', null, 'jcms-connector');
    add_settings_field('plugin_text_input3_1', 'Connection name', 'plugin_input3_1', 'jcms-connector', 'jcms_connector_s3');
    add_settings_field('plugin_text_input3_2', 'Server root', 'plugin_input3_2', 'jcms-connector', 'jcms_connector_s3');
    add_settings_field('plugin_text_input3_3', 'Script name', 'plugin_input3_3', 'jcms-connector', 'jcms_connector_s3');
    add_settings_field('plugin_text_input3_4', 'URL paramter name', 'plugin_input3_4', 'jcms-connector', 'jcms_connector_s3');
    add_settings_field('plugin_text_input3_5', 'Content path', 'plugin_input3_5', 'jcms-connector', 'jcms_connector_s3');
    add_settings_field('plugin_text_input3_6', 'Cache time', 'plugin_input3_6', 'jcms-connector', 'jcms_connector_s3');
}

// function plugin_section_text() {
//     echo '<p>New input setting to be saved.</p>';
// }

/*
 * Note the syntax below for the names - WordPress/PHP(?) will interpret that syntax to control the object being built.
 * Here, the section options are built into a nested array co collect the settings for each section into a logical block.
 * [TODO - write about this!!]
 * */

//callbacks for section 1:
function plugin_input1_1() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input1_1' class='normal-text code' name='jcms_connector_opts[1][1]' size='50' type='text' value='{$options[1][1]}' />";
}
function plugin_input1_2() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input1_2' class='normal-text code' name='jcms_connector_opts[1][2]' size='50' type='text' value='{$options[1][2]}' />";
}
function plugin_input1_3() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input1_3' class='normal-text code' name='jcms_connector_opts[1][3]' size='50' type='text' value='{$options[1][3]}' />";
}
function plugin_input1_4() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input1_4' class='normal-text code' name='jcms_connector_opts[1][4]' size='50' type='text' value='{$options[1][4]}' />";
}
function plugin_input1_5() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input1_5' class='normal-text code' name='jcms_connector_opts[1][5]' size='50' type='text' value='{$options[1][5]}' />";
}

function plugin_input1_6() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input1_6' class='normal-text code' name='jcms_connector_opts[1][6]' size='50' type='text' value='{$options[1][6]}' />";
}


//callbacks for section 2:
function plugin_input2_1() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input2_1' class='normal-text code' name='jcms_connector_opts[2][1]' size='50' type='text' value='{$options[2][1]}' />";
}
function plugin_input2_2() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input2_2' class='normal-text code' name='jcms_connector_opts[2][2]' size='50' type='text' value='{$options[2][2]}' />";
}
function plugin_input2_3() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input2_3' class='normal-text code' name='jcms_connector_opts[2][3]' size='50' type='text' value='{$options[2][3]}' />";
}
function plugin_input2_4() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input2_4' class='normal-text code' name='jcms_connector_opts[2][4]' size='50' type='text' value='{$options[2][4]}' />";
}
function plugin_input2_5() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input2_5' class='normal-text code' name='jcms_connector_opts[2][5]' size='50' type='text' value='{$options[2][5]}' />";
}
function plugin_input2_6() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input2_6' class='normal-text code' name='jcms_connector_opts[2][6]' size='50' type='text' value='{$options[2][6]}' />";
}

//callbacks for section 3:
function plugin_input3_1() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input3_1' class='normal-text code' name='jcms_connector_opts[3][1]' size='50' type='text' value='{$options[3][1]}' />";
}
function plugin_input3_2() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input3_2' class='normal-text code' name='jcms_connector_opts[3][2]' size='50' type='text' value='{$options[3][2]}' />";
}
function plugin_input3_3() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input3_3' class='normal-text code' name='jcms_connector_opts[3][3]' size='50' type='text' value='{$options[3][3]}' />";
}
function plugin_input3_4() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input3_4' class='normal-text code' name='jcms_connector_opts[3][4]' size='50' type='text' value='{$options[3][4]}' />";
}
function plugin_input3_5() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input3_5' class='normal-text code' name='jcms_connector_opts[3][5]' size='50' type='text' value='{$options[3][5]}' />";
}
function plugin_input3_6() {
    $options = get_option('jcms_connector_opts');
    echo "<input id='plugin_input3_6' class='normal-text code' name='jcms_connector_opts[3][6]' size='50' type='text' value='{$options[3][6]}' />";
}

//TODO: Expand this to validate properly:
function plugin_options_validate($input) {
    $options = get_option('jcms_connector_opts');
    echo($input);
//     $options['text_string'] = trim($input['text_string']);
//     if(!preg_match('/^[a-z0-9]{32}$/i', $options['text_string'])) {
//         $options['text_string'] = '';
//     }
    return $options;
}